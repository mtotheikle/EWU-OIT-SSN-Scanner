java-libpst is a pure java library for the reading of Outlook PST and OST files.

For usage example, please see the javadocs and the example program located in the example package.

java-libpst is licensed under both the LGPL and Apache License v2.0